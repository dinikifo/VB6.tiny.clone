import json
import sys
from PySide6.QtWidgets import QApplication

try:
    from tinyvb_webext import runtime, interpreter, gui
except ImportError:
    # Fallback to local modules in the same folder
    import runtime, interpreter, gui


# A simple WinForms-like layout for entering double-entry postings.
# The form lets you:
# - Enter journal header: date, period, description
# - Enter two accounts and an amount
# - Post a balanced pair using PostEntry
# - See a running list of postings in a ListBox

FORM_JSON = """
{
  "name": "MainForm",
  "title": "Double-Entry Demo",
  "width": 800,
  "height": 600,
  "controls": [
    {
      "id": "lblDate",
      "type": "Label",
      "text": "Date (YYYY-MM-DD)",
      "x": 20,
      "y": 20,
      "width": 160,
      "height": 24
    },
    {
      "id": "txtDate",
      "name": "txtDate",
      "type": "TextBox",
      "text": "",
      "x": 200,
      "y": 20,
      "width": 140,
      "height": 24
    },
    {
      "id": "lblPeriod",
      "type": "Label",
      "text": "Period (YYYY-MM)",
      "x": 20,
      "y": 60,
      "width": 160,
      "height": 24
    },
    {
      "id": "txtPeriod",
      "name": "txtPeriod",
      "type": "TextBox",
      "text": "",
      "x": 200,
      "y": 60,
      "width": 140,
      "height": 24
    },
    {
      "id": "lblDesc",
      "type": "Label",
      "text": "Description",
      "x": 20,
      "y": 100,
      "width": 160,
      "height": 24
    },
    {
      "id": "txtDesc",
      "name": "txtDesc",
      "type": "TextBox",
      "text": "",
      "x": 200,
      "y": 100,
      "width": 260,
      "height": 24
    },

    {
      "id": "lblAccount1",
      "type": "Label",
      "text": "Account A (code)",
      "x": 20,
      "y": 150,
      "width": 160,
      "height": 24
    },
    {
      "id": "txtAccount1",
      "name": "txtAccount1",
      "type": "TextBox",
      "text": "CASH",
      "x": 200,
      "y": 150,
      "width": 140,
      "height": 24
    },
    {
      "id": "lblAccount2",
      "type": "Label",
      "text": "Account B (code)",
      "x": 20,
      "y": 190,
      "width": 160,
      "height": 24
    },
    {
      "id": "txtAccount2",
      "name": "txtAccount2",
      "type": "TextBox",
      "text": "GROCERIES",
      "x": 200,
      "y": 190,
      "width": 140,
      "height": 24
    },
    {
      "id": "lblAmount",
      "type": "Label",
      "text": "Amount",
      "x": 20,
      "y": 230,
      "width": 160,
      "height": 24
    },
    {
      "id": "txtAmount",
      "name": "txtAmount",
      "type": "TextBox",
      "text": "100",
      "x": 200,
      "y": 230,
      "width": 140,
      "height": 24
    },

    {
      "id": "btnNewJournal",
      "name": "btnNewJournal",
      "type": "Button",
      "text": "New Journal",
      "x": 380,
      "y": 20,
      "width": 140,
      "height": 30,
      "bind": "",
      "events": {
        "click": "btnNewJournal_Click"
      }
    },
    {
      "id": "btnPost",
      "name": "btnPost",
      "type": "Button",
      "text": "Post Pair",
      "x": 380,
      "y": 60,
      "width": 140,
      "height": 30,
      "bind": "",
      "events": {
        "click": "btnPost_Click"
      }
    },

    {
      "id": "lblPostings",
      "type": "Label",
      "text": "Postings (most recent at bottom)",
      "x": 20,
      "y": 280,
      "width": 260,
      "height": 24
    },
    {
      "id": "lstPostings",
      "name": "lstPostings",
      "type": "ListBox",
      "x": 20,
      "y": 310,
      "width": 740,
      "height": 260
    }
  ]
}
"""

# TinyVB script that drives the form.
# It uses:
#   NewJournal(date, description, [period]) -> journal id
#   PostEntry accountCode, assetTypeCode, period, journalId, amount
#
# For simplicity we use a single currency code "CUR". The JSON layer
# keeps (account, assetType, journal, posting) arrays consistent.

SCRIPT_TEXT = r"""
Dim currentJournalId

Sub MainForm_Load()
    ' Start with no active journal
    Dim tmp
    currentJournalId = 0
End Sub

Sub btnNewJournal_Click()
    Dim p
    p = txtPeriod.Text
    If p = "" Then
        p = "0000-00"
    End If

    currentJournalId = NewJournal(txtDate.Text, txtDesc.Text, p)
    lstPostings.Add "New journal created: ID=" & currentJournalId & ", period=" & p
End Sub

Sub btnPost_Click()
    Dim p, a1, a2, amt

    p = txtPeriod.Text
    If p = "" Then
        p = "0000-00"
    End If

    a1 = txtAccount1.Text
    a2 = txtAccount2.Text
    amt = txtAmount.Text

    If currentJournalId = 0 Then
        currentJournalId = NewJournal(txtDate.Text, txtDesc.Text, p)
        lstPostings.Add "Auto-created journal: ID=" & currentJournalId
    End If

    ' Debit A, credit B (or vice versa depending on sign convention).
    ' The important bit is that the pair sums to zero.
    PostEntry a1, "CUR", p, currentJournalId, amt
    PostEntry a2, "CUR", p, currentJournalId, -amt

    lstPostings.Add "J" & currentJournalId & ": " & a1 & " / " & a2 & " = " & amt
End Sub
"""




def populate_postings_list(ctx):
    """Fill lstPostings with any postings already present in the JSON ledger.

    This makes the existing sample ledger.json visible as soon as the app
    starts, proving that data entry and persistence work even before you
    add new entries.
    """
    try:
        app_data = ctx.get_var("AppData")
    except Exception:
        app_data = None

    if not isinstance(app_data, dict):
        return

    ledger = app_data.get("ledger", {})
    postings = ledger.get("postings", [])
    accounts = {a.get("id"): a for a in ledger.get("accounts", []) if isinstance(a, dict)}

    lst = ctx.get_var("lstPostings")
    if lst is None:
        return

    # Avoid duplicating lines if VB script has already added some
    try:
        lst.Clear()
    except Exception:
        pass

    for p in postings:
        if not isinstance(p, dict):
            continue
        jid = p.get("journalId", "")
        acc_id = p.get("accountId")
        acc = accounts.get(acc_id, {})
        acc_code = acc.get("code", f"#{acc_id}")
        amount = p.get("amount", 0)
        period = p.get("period", "")
        line = f"J{jid} | {acc_code} | {amount} | {period}"
        try:
            lst.Add(line)
        except Exception:
            # If for some reason lst is not a VBListBox wrapper with Add(), skip
            continue


def main():
    form_def = json.loads(FORM_JSON)

    # Prepare VB context and AppData JSON store
    ctx = runtime.VBContext()

    # Load or initialise the Root JSON using the accounting schema
    app_data = runtime.load_app_data()
    ctx.set_var("AppData", app_data)

    # Set up the interpreter with our TinyVB script
    interp = interpreter.VBInterpreter(ctx)
    interp.load_source(SCRIPT_TEXT)

    app = QApplication(sys.argv)
    form = gui.VBForm(form_def, interp, ctx)
    form.setWindowTitle(form_def.get("title", form_def.get("name", "TinyVB App")))

    # Populate the postings list from any existing JSON ledger data so the
    # sample ledger is visible immediately.
    populate_postings_list(ctx)

    form.show()

    # Run the event loop; when the window closes, save the ledger JSON
    exit_code = app.exec()
    runtime.save_app_data(app_data)

    sys.exit(exit_code)


if __name__ == "__main__":
    main()
