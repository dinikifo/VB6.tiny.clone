import json
import sys
from PySide6.QtWidgets import QApplication

try:
    from tinyvb_webext import runtime, interpreter, gui
except ImportError:
    # Fallback to local modules in the same folder
    import runtime, interpreter, gui


FORM_JSON = """{
  "name": "RegressionForm",
  "title": "Account Trend (Linear Regression)",
  "width": 700,
  "height": 400,
  "controls": [
    {
      "id": "lblAccount",
      "type": "Label",
      "text": "Account code",
      "x": 20,
      "y": 20,
      "width": 120,
      "height": 24
    },
    {
      "id": "txtAccount",
      "name": "txtAccount",
      "type": "TextBox",
      "x": 150,
      "y": 20,
      "width": 160,
      "height": 24
    },
    {
      "id": "lblFrom",
      "type": "Label",
      "text": "From period (YYYY-MM)",
      "x": 20,
      "y": 60,
      "width": 160,
      "height": 24
    },
    {
      "id": "txtFromPeriod",
      "name": "txtFromPeriod",
      "type": "TextBox",
      "x": 190,
      "y": 60,
      "width": 120,
      "height": 24
    },
    {
      "id": "lblTo",
      "type": "Label",
      "text": "To period (YYYY-MM)",
      "x": 330,
      "y": 60,
      "width": 160,
      "height": 24
    },
    {
      "id": "txtToPeriod",
      "name": "txtToPeriod",
      "type": "TextBox",
      "x": 500,
      "y": 60,
      "width": 120,
      "height": 24
    },
    {
      "id": "btnRunRegression",
      "name": "btnRunRegression",
      "type": "Button",
      "text": "Analyze trend",
      "x": 530,
      "y": 20,
      "width": 120,
      "height": 30,
      "events": {
        "click": "btnRunRegression_Click"
      }
    },
    {
      "id": "lblResult",
      "type": "Label",
      "text": "Regression result",
      "x": 20,
      "y": 110,
      "width": 150,
      "height": 24
    },
    {
      "id": "lstRegression",
      "name": "lstRegression",
      "type": "ListBox",
      "x": 20,
      "y": 140,
      "width": 660,
      "height": 220
    }
  ]
}"""


SCRIPT_TEXT = r"""
Dim currentRegId

Sub RegressionForm_Load()
    currentRegId = ""
End Sub

Sub btnRunRegression_Click()
    Dim acc, pFrom, pTo
    Dim slope, intercept, r2

    acc = txtAccount.Text
    pFrom = txtFromPeriod.Text
    pTo   = txtToPeriod.Text

    lstRegression.Clear

    If acc = "" Then
        MsgBox "Please enter an account code."
        Exit Sub
    End If

    If pFrom = "" Or pTo = "" Then
        MsgBox "Please enter both From and To periods (e.g. 2025-01)."
        Exit Sub
    End If

    currentRegId = RegPrepare(acc, pFrom, pTo)

    If currentRegId = "" Then
        lstRegression.Add "Not enough data for a trend on " & acc & " between " & pFrom & " and " & pTo & "."
        Exit Sub
    End If

    slope     = RegGet(currentRegId, "slope")
    intercept = RegGet(currentRegId, "intercept")
    r2        = RegGet(currentRegId, "r2")

    lstRegression.Add "Trend for " & acc & " (" & pFrom & " to " & pTo & "):"
    lstRegression.Add ""
    lstRegression.Add "  Slope:     " & slope
    lstRegression.Add "  Intercept: " & intercept
    lstRegression.Add "  R^2:       " & r2

    If slope > 0 Then
        lstRegression.Add "  Interpretation: increasing over time."
    ElseIf slope < 0 Then
        lstRegression.Add "  Interpretation: decreasing over time."
    Else
        lstRegression.Add "  Interpretation: (approximately) flat trend."
    End If
End Sub
"""


def _find_account_id(app_data, code):
    ledger = app_data.get("ledger", {})
    accounts = ledger.get("accounts", [])
    for a in accounts:
        if isinstance(a, dict) and a.get("code") == code:
            return a.get("id")
    return None


def build_account_series(app_data, account_code, period_from, period_to):
    ledger = app_data.get("ledger", {})
    postings = ledger.get("postings", [])

    acc_id = _find_account_id(app_data, account_code)
    if acc_id is None:
        return []

    sums = {}
    for p in postings:
        if not isinstance(p, dict):
            continue
        if p.get("accountId") != acc_id:
            continue
        period = str(p.get("period", ""))
        if period_from and period < period_from:
            continue
        if period_to and period > period_to:
            continue
        try:
            amt = float(p.get("amount", 0.0))
        except (TypeError, ValueError):
            amt = 0.0
        sums[period] = sums.get(period, 0.0) + amt

    return sorted(sums.items(), key=lambda kv: kv[0])


def regression_on_values(values):
    n = len(values)
    if n < 2:
        return None

    xs = list(range(n))
    mean_x = sum(xs) / n
    mean_y = sum(values) / n

    num = sum((x - mean_x) * (y - mean_y) for x, y in zip(xs, values))
    den = sum((x - mean_x) ** 2 for x in xs)
    if den == 0:
        return None

    slope = num / den
    intercept = mean_y - slope * mean_x

    ss_tot = sum((y - mean_y) ** 2 for y in values)
    ss_res = sum((y - (slope * x + intercept)) ** 2 for x, y in zip(xs, values))
    r2 = 1 - ss_res / ss_tot if ss_tot != 0 else 0.0

    return {
        "slope": slope,
        "intercept": intercept,
        "r2": r2
    }


def run_regression_analysis(app_data, account_code, period_from, period_to):
    series = build_account_series(app_data, account_code, period_from, period_to)
    values = [float(v) for _, v in series]
    if len(values) < 2:
        return None

    reg = regression_on_values(values)

    analysis_id = f"reg:{account_code}:{period_from}:{period_to}"
    analysis = app_data.setdefault("analysis", {})
    analysis[analysis_id] = {
        "type": "regression",
        "account": account_code,
        "period_from": period_from,
        "period_to": period_to,
        "series": series,
        "regression": reg,
    }
    return analysis_id


def get_reg_value(app_data, analysis_id, key):
    analysis = app_data.get("analysis", {})
    entry = analysis.get(analysis_id)
    if not isinstance(entry, dict):
        return 0.0
    if entry.get("type") != "regression":
        return 0.0
    reg = entry.get("regression", {})
    return reg.get(key, 0.0)


class RegressionVBInterpreter(interpreter.VBInterpreter):
    def _call_function(self, name, args):
        upper = name.upper()

        if upper == "REGPREPARE":
            app_data = self.ctx.get_var("AppData")
            account_code = str(args[0]) if len(args) > 0 else ""
            period_from = str(args[1]) if len(args) > 1 else ""
            period_to = str(args[2]) if len(args) > 2 else ""
            if not account_code:
                return ""
            analysis_id = run_regression_analysis(app_data, account_code, period_from, period_to)
            return analysis_id or ""

        if upper == "REGGET":
            app_data = self.ctx.get_var("AppData")
            analysis_id = str(args[0]) if len(args) > 0 else ""
            key = str(args[1]) if len(args) > 1 else ""
            return get_reg_value(app_data, analysis_id, key)

        return super()._call_function(name, args)


def main():
    form_def = json.loads(FORM_JSON)

    ctx = runtime.VBContext()
    app_data = runtime.load_app_data()
    ctx.set_var("AppData", app_data)

    interp = RegressionVBInterpreter(ctx)
    interp.load_source(SCRIPT_TEXT)

    app = QApplication(sys.argv)
    form = gui.VBForm(form_def, interp, ctx)

    form.show()
    exit_code = app.exec()

    runtime.save_app_data(app_data)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
