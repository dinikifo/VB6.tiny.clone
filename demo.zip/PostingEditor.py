import json
import sys
from PySide6.QtWidgets import QApplication

try:
    from tinyvb_webext import runtime, interpreter, gui
except ImportError:
    # Prefer local modules in this folder
    import runtime, interpreter, gui


FORM_JSON = """{
  "name": "PostingEditorForm",
  "title": "Posting Editor (Admin)",
  "width": 800,
  "height": 420,
  "controls": [
    {
      "id": "lblInfo",
      "type": "Label",
      "x": 20,
      "y": 10,
      "width": 760,
      "height": 20,
      "text": "Select a posting on the left, then edit period/amount/memo and click Save."
    },
    {
      "id": "lstPostings",
      "name": "lstPostings",
      "type": "ListBox",
      "x": 20,
      "y": 40,
      "width": 360,
      "height": 320,
      "events": {
        "click": "lstPostings_Click"
      }
    },
    {
      "id": "lblIndex",
      "type": "Label",
      "x": 400,
      "y": 40,
      "width": 80,
      "height": 20,
      "text": "Index:"
    },
    {
      "id": "txtIndex",
      "name": "txtIndex",
      "type": "TextBox",
      "x": 480,
      "y": 40,
      "width": 80,
      "height": 20
    },
    {
      "id": "lblPostingId",
      "type": "Label",
      "x": 580,
      "y": 40,
      "width": 80,
      "height": 20,
      "text": "Posting ID:"
    },
    {
      "id": "txtPostingId",
      "name": "txtPostingId",
      "type": "TextBox",
      "x": 660,
      "y": 40,
      "width": 100,
      "height": 20
    },
    {
      "id": "lblJournalId",
      "type": "Label",
      "x": 400,
      "y": 70,
      "width": 80,
      "height": 20,
      "text": "Journal ID:"
    },
    {
      "id": "txtJournalId",
      "name": "txtJournalId",
      "type": "TextBox",
      "x": 480,
      "y": 70,
      "width": 80,
      "height": 20
    },
    {
      "id": "lblAccount",
      "type": "Label",
      "x": 400,
      "y": 100,
      "width": 80,
      "height": 20,
      "text": "Account:"
    },
    {
      "id": "txtAccountInfo",
      "name": "txtAccountInfo",
      "type": "TextBox",
      "x": 480,
      "y": 100,
      "width": 280,
      "height": 20
    },
    {
      "id": "lblPeriod",
      "type": "Label",
      "x": 400,
      "y": 140,
      "width": 80,
      "height": 20,
      "text": "Period:"
    },
    {
      "id": "txtPeriod",
      "name": "txtPeriod",
      "type": "TextBox",
      "x": 480,
      "y": 140,
      "width": 120,
      "height": 20
    },
    {
      "id": "lblAmount",
      "type": "Label",
      "x": 400,
      "y": 170,
      "width": 80,
      "height": 20,
      "text": "Amount:"
    },
    {
      "id": "txtAmount",
      "name": "txtAmount",
      "type": "TextBox",
      "x": 480,
      "y": 170,
      "width": 120,
      "height": 20
    },
    {
      "id": "lblMemo",
      "type": "Label",
      "x": 400,
      "y": 210,
      "width": 80,
      "height": 20,
      "text": "Memo:"
    },
    {
      "id": "txtMemo",
      "name": "txtMemo",
      "type": "TextArea",
      "x": 480,
      "y": 210,
      "width": 280,
      "height": 80
    },
    {
      "id": "btnSave",
      "name": "btnSave",
      "type": "Button",
      "x": 400,
      "y": 310,
      "width": 120,
      "height": 30,
      "text": "Save Changes",
      "events": {
        "click": "btnSave_Click"
      }
    },
    {
      "id": "btnDelete",
      "name": "btnDelete",
      "type": "Button",
      "x": 540,
      "y": 310,
      "width": 120,
      "height": 30,
      "text": "Delete Posting",
      "events": {
        "click": "btnDelete_Click"
      }
    },
    {
      "id": "btnClose",
      "name": "btnClose",
      "type": "Button",
      "x": 680,
      "y": 310,
      "width": 80,
      "height": 30,
      "text": "Close",
      "events": {
        "click": "btnClose_Click"
      }
    }
  ]
}"""


SCRIPT_TEXT = r"""
Dim currentIndex

Sub MainForm_Load()
    currentIndex = -1
End Sub

Sub lstPostings_Click()
    Dim idx, basePath
    idx = lstPostings.SelectedIndex
    If idx < 0 Then
        Exit Sub
    End If

    currentIndex = idx
    txtIndex.Text = idx

    basePath = "ledger.postings[" & idx & "]"

    txtPostingId.Text = JsonGet(AppData, basePath & ".id")
    txtJournalId.Text = JsonGet(AppData, basePath & ".journalId")
    txtPeriod.Text = JsonGet(AppData, basePath & ".period")
    txtAmount.Text = JsonGet(AppData, basePath & ".amount")

    Dim accId, accCode
    accId = JsonGet(AppData, basePath & ".accountId")
    accCode = ""
    If accId > 0 Then
        accCode = JsonGet(AppData, "ledger.accounts[" & (accId - 1) & "].code")
    End If
    txtAccountInfo.Text = "ID=" & accId & " Code=" & accCode

    Dim memoVal
    memoVal = JsonGet(AppData, basePath & ".memo")
    If memoVal = "" Then
        txtMemo.Text = ""
    Else
        txtMemo.Text = memoVal
    End If
End Sub

Sub btnSave_Click()
    If currentIndex < 0 Then
        MsgBox "Please select a posting first."
        Exit Sub
    End If

    If txtAmount.Text = "" Then
        MsgBox "Amount cannot be empty."
        Exit Sub
    End If

    EditPosting currentIndex, txtPeriod.Text, txtAmount.Text, txtMemo.Text
    MsgBox "Posting updated. Note: the list is not auto-refreshed; reopen the editor to see updated summary text."
End Sub

Sub btnDelete_Click()
    If currentIndex < 0 Then
        MsgBox "Please select a posting first."
        Exit Sub
    End If

    DeletePosting currentIndex
    MsgBox "Posting deleted. Close and reopen the editor to refresh the list."
End Sub

Sub btnClose_Click()
    End
End Sub
"""


def populate_postings_list(ctx):
    """Populate lstPostings with a simple summary per posting.

    Row index in the list matches index in ledger.postings.
    """
    app_data = ctx.get_var("AppData")
    app_data = runtime._ensure_root_defaults(app_data)
    ledger = app_data["ledger"]
    postings = ledger.get("postings", [])
    accounts = {a["id"]: a for a in ledger.get("accounts", [])}

    lst = ctx.get_var("lstPostings")
    if lst is None:
        return

    lst.Clear()

    for idx, p in enumerate(postings):
        acc = accounts.get(p.get("accountId"))
        acc_code = acc.get("code") if acc else "?"
        line = f"{idx}: jr={p.get('journalId')} acc={acc_code} per={p.get('period')} amt={p.get('amount')}"
        lst.Add(line)


def main():
    app_data = runtime.load_app_data()
    app_data = runtime._ensure_root_defaults(app_data)

    ctx = runtime.VBContext()
    ctx.set_var("AppData", app_data)

    form_def = json.loads(FORM_JSON)
    interp = interpreter.VBInterpreter(ctx)
    interp.load_source(SCRIPT_TEXT)

    app = QApplication(sys.argv)
    form = gui.VBForm(form_def, interp, ctx)

    # After form + controls are in the context, populate the postings list
    populate_postings_list(ctx)

    form.show()
    exit_code = app.exec()

    runtime.save_app_data(app_data)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
